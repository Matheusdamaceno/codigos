public class cliente {
  private String nome;
  private String end;
  private int codC;

  public String getNome() {
    return this.nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getEnd() {
    return this.end;
  }

  public void setEnd(String end) {
    this.end = end;
  }

  public int getCodC() {
    return this.codC;
  }

  public void setCodC(int codC) {
    this.codC = codC;
  }

}
