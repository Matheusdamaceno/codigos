public class App {
    public static void main(String[] args) throws Exception {
        menu m = new menu();
        m.gerenciarMenu();
    }
}
