public class vendedor extends empregado {
  private float percentual;

  public float getPercentual() {
    return this.percentual;
  }

  public void setPercentual(float percentual) {
    this.percentual = percentual;
  }

}
