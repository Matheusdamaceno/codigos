public class gerente extends empregado {
  private String depart;

  public String getDepart() {
    return this.depart;
  }

  public void setDepart(String depart) {
    this.depart = depart;
  }

}
