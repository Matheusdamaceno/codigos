public class ProjetoPokedex {
    public static void main(String[] args) throws Exception {
        pokedex p = new pokedex();
        p.executar();
    }
}
