public class pokemon {
  private String nome;
  private String tipo;

  public String getTipo() {
    return this.tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  private int vida;
  private int atk;
  private int def;

  public String getNome() {
    return this.nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public int getVida() {
    return this.vida;
  }

  public void setVida(int vida) {
    this.vida = vida;
  }

  public int getAtk() {
    return this.atk;
  }

  public void setAtk(int atk) {
    this.atk = atk;
  }

  public int getDef() {
    return this.def;
  }

  public void setDef(int def) {
    this.def = def;
  }

}
