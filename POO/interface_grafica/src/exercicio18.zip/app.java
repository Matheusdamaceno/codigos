
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/**
 *
 * @author Matheus
 */
public class app {

    public static void main(String[] args) {
        // instanciar a janela (jframe)
        gerenciador g = new gerenciador();
    }
}
